#----------------------------------------------------------------------------------------------------------
#
# AUTOMATICALLY GENERATED FILE TO BE USED BY W_HOTBOX
#
# NAME: Set PointSize
#
#----------------------------------------------------------------------------------------------------------

for i in nuke.selectedNodes():
    i.knob('pointSize').setValue(1)
    i.knob('detail').setValue(1)