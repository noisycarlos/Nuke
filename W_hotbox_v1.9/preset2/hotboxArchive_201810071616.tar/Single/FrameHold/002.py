#----------------------------------------------------------------------------------------------------------
#
# AUTOMATICALLY GENERATED FILE TO BE USED BY W_HOTBOX
#
# NAME: Jump to frame
#
#----------------------------------------------------------------------------------------------------------

nuke.frame(nuke.selectedNode().knob('first_frame').value())